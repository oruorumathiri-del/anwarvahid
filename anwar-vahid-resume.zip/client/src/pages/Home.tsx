/**
 * Design system: Editorial Industrial Portfolio — warm paper, pine-black chapters,
 * Signal Lime accent, Space Grotesk display type, deliberate documentary rhythm.
 */
import {
  ArrowDownRight,
  ArrowUpRight,
  BriefcaseBusiness,
  ChevronDown,
  CircleDot,
  FileText,
  Mail,
  MapPin,
  MoveRight,
  Network,
  Phone,
  Ruler,
  Target,
} from "lucide-react";

const imageAssets = {
  hero: "/manus-storage/anwar-hero-industrial-editorial_005d905e.jpg",
  estimate: "/manus-storage/anwar-technical-estimating-editorial_d038dd45.jpg",
  civil: "/manus-storage/anwar-civil-infrastructure-editorial_09f0b0c9.jpg",
  alignment: "/manus-storage/anwar-client-alignment-editorial_d738a8d4.jpg",
  logo: "/manus-storage/anwar-av-monogram_88b6b19a.png",
};

type CareerRole = {
  number: string;
  company: string;
  period: string;
  location: string;
  title: string;
  summary: string;
  image: string;
  scope: string[];
  stakeholders: string[];
  responsibilities: string[];
  added: string;
};

const roles: CareerRole[] = [
  {
    number: "01",
    company: "Geofabrics Australasia",
    period: "Jul 2025 — Present",
    location: "Melbourne, VIC",
    title: "Technical Sales & Account Management",
    summary:
      "Technical sales and account management for geosynthetic solutions across civil, mining and environmental infrastructure.",
    image: imageAssets.civil,
    scope: ["Technical sales", "Product specification", "RFQ / RFT management", "Quotations & tenders", "Key accounts", "Site support"],
    stakeholders: ["Contractors", "Consulting engineers", "Asset owners", "Authorities", "Distributors", "Logistics"],
    responsibilities: [
      "Interpret drawings, specifications and design documentation to recommend compliant geosynthetic systems.",
      "Manage enquiry-to-quote activity through tender submission and order handover, coordinating pricing, stock and logistics.",
      "Deliver technical presentations, product demonstrations and training for customers and distribution partners.",
      "Translate site conditions into commercially viable recommendations with product management and R&D.",
    ],
    added: "Complex infrastructure applications, specification-led sales and end-to-end supply coordination.",
  },
  {
    number: "02",
    company: "All Metal Solutions Pty Ltd",
    period: "Mar 2022 — Mar 2025",
    location: "Mackay, QLD",
    title: "Business Development & Estimating",
    summary:
      "Commercial and estimating role inside a custom steel and aluminium fabrication business, connecting client requirements to manufacturable work.",
    image: imageAssets.estimate,
    scope: ["Business development", "Key accounts", "Cost estimating", "BOQs / drawings", "Tendering", "Project handover"],
    stakeholders: ["Construction clients", "Industrial clients", "Suppliers", "Subcontractors", "Production", "Operations"],
    responsibilities: [
      "Identify fabrication opportunities through market research, prospecting and industry networks.",
      "Prepare cost estimates, quotations and tenders from drawings, specifications and bills of quantities.",
      "Negotiate pricing, delivery schedules and commercial terms while balancing cost, quality and programme.",
      "Manage the sales cycle from technical consultation through proposal, negotiation and project handover.",
    ],
    added: "A direct line between commercial opportunity, manufacturability and operational delivery.",
  },
  {
    number: "03",
    company: "Sun Precision Engineering",
    period: "Feb 2021 — Feb 2022",
    location: "Melbourne, VIC",
    title: "Customer Management, CAD/CAM & Production",
    summary:
      "Precision fabrication chapter combining customer management, estimating, CAD/CAM programming and production supervision.",
    image: imageAssets.estimate,
    scope: ["Steel & laser cutting", "Brake pressing", "Plate rolling", "CAD/CAM", "TruTops", "Quality control"],
    stakeholders: ["Customers", "Production teams", "Engineering", "Suppliers", "Quality stakeholders"],
    responsibilities: [
      "Coordinate projects from enquiry through quotation, production and delivery.",
      "Prepare technical estimates and quotations by interpreting drawings and specifications.",
      "Review and modify technical drawings and program TruLaser production work using TruTops.",
      "Plan workflow, allocate machines and develop inspection jigs to identify quality issues earlier.",
    ],
    added: "Hands-on fabrication fluency, production planning and quality assurance discipline.",
  },
  {
    number: "04",
    company: "Green Home Green Planet",
    period: "May 2019 — Aug 2019",
    location: "NSW",
    title: "Field Sales & Site Assessment",
    summary:
      "Field sales and site-assessment role supporting the NSW Discounted Energy Efficient Lighting Program.",
    image: imageAssets.alignment,
    scope: ["Site assessment", "Energy efficiency", "Client consultation", "Measurements", "Sign-off", "Handover"],
    stakeholders: ["Commercial clients", "Residential clients", "Installation teams", "Program stakeholders"],
    responsibilities: [
      "Assess lighting infrastructure, energy-consumption patterns and spatial constraints on site.",
      "Review eligibility and prepare tailored upgrade proposals grounded in client requirements.",
      "Secure sign-off and hand over clear scopes, specifications and implementation guidance to installation teams.",
    ],
    added: "Evidence-led field consultation and precise installation handover.",
  },
  {
    number: "05",
    company: "UniGAZ",
    period: "Feb 2015 — May 2018",
    location: "Qatar",
    title: "Technical Sales Engineer → Sales Manager",
    summary:
      "Technical sales and account-governance role across gas distribution, LPG/SNG systems and hazardous gas mitigation that developed into sales leadership.",
    image: imageAssets.hero,
    scope: ["Gas distribution", "LPG / SNG", "Gas mitigation", "Technical proposals", "AutoCAD", "Sales leadership"],
    stakeholders: ["Industrial clients", "Engineering", "Compliance", "Field teams", "Sales team"],
    responsibilities: [
      "Manage technical sales and account governance for gas distribution networks and high-risk detection infrastructure.",
      "Prepare client proposals that address safety requirements while considering investment and operational return.",
      "Lead a five-person sales team after restructuring the pipeline and entering new sectors.",
      "Improve proposal turnaround through CAD-based schematics and CRM automation while mentoring junior staff.",
    ],
    added: "High-consequence technical selling, account governance and sales-team leadership.",
  },
  {
    number: "06",
    company: "Global Energy Trading",
    period: "Mar 2013 — Feb 2015",
    location: "Saudi Arabia",
    title: "Technical Sales Engineering",
    summary:
      "Technical sales engineering role supporting consultants, property stakeholders and government clients across the Saudi market.",
    image: imageAssets.alignment,
    scope: ["Technical proposals", "Negotiation", "Pricing", "Freight", "Market research", "Quotation process"],
    stakeholders: ["Engineering consultants", "Property stakeholders", "Authorities", "Customers"],
    responsibilities: [
      "Develop technical solutions for active projects and help resolve delivery issues through engineering and commercial judgement.",
      "Negotiate pricing, discounts, freight logistics and delivery timelines to reach viable commercial terms.",
      "Benchmark competitors and introduce computer-based quotation workflows to reduce errors and improve turnaround.",
    ],
    added: "Commercial negotiation, market intelligence and delivery-aware proposal development.",
  },
  {
    number: "07",
    company: "Xeniq Scientific Solutions",
    period: "Jul 2011 — Dec 2012",
    location: "India",
    title: "Technical Sales Foundations",
    summary:
      "The first technical-sales chapter, building the foundation for consultative selling of specialist lighting products.",
    image: imageAssets.civil,
    scope: ["Lighting solutions", "Architect engagement", "Product selection", "Documentation", "Order entry", "Negotiation"],
    stakeholders: ["Architects", "Engineers", "Design teams", "Clients", "Proposal team"],
    responsibilities: [
      "Engage architects, engineers and design teams around technically suitable lighting selections.",
      "Prepare documentation, scopes and proposals that connect product specification to client needs.",
      "Support order entry, commercial discussions and coordination with delivery stakeholders.",
    ],
    added: "The consultative sales foundation: listen carefully, specify accurately and follow through.",
  },
];

const decisionSteps = [
  ["01", "Understand the requirement", "Read drawings, specifications, site conditions, quantities and performance requirements.", imageAssets.estimate],
  ["02", "Translate technically", "Interpret application constraints, product options and buildability.", imageAssets.civil],
  ["03", "Test commercial reality", "Check cost, lead time, availability, freight, risk, pricing and margin.", imageAssets.hero],
  ["04", "Align the stakeholders", "Bring engineering, procurement, production, logistics and the customer into one decision.", imageAssets.alignment],
  ["05", "Make the next action obvious", "Turn the recommendation into a quote, proposal, specification, order or handover.", imageAssets.estimate],
];

function RuleLabel({ children }: { children: React.ReactNode }) {
  return <p className="rule-label">{children}</p>;
}

function SectionTitle({ eyebrow, title, copy }: { eyebrow: string; title: React.ReactNode; copy?: string }) {
  return (
    <div className="section-heading">
      <div>
        <RuleLabel>{eyebrow}</RuleLabel>
        <h2>{title}</h2>
      </div>
      {copy && <p className="section-copy">{copy}</p>}
    </div>
  );
}

export default function Home() {
  return (
    <div className="resume-shell">
      <header className="site-header">
        <div className="frame nav-inner">
          <a className="brand" href="#top" aria-label="Anwar Vahid, back to top">
            <span className="brand-mark"><img src={imageAssets.logo} alt="" /><i aria-hidden="true">AV</i></span>
            <span className="brand-text">Anwar Vahid <small>Career engineered</small></span>
          </a>
          <nav className="desktop-nav" aria-label="Primary navigation">
            <a href="#journey">Journey</a><a href="#decision">Decision pattern</a><a href="#experience">Experience</a><a href="#capabilities">Capabilities</a>
          </nav>
          <a className="header-cta" href="#contact">Contact <ArrowUpRight size={14} /></a>
        </div>
      </header>

      <main id="top">
        <section className="hero">
          <div className="hero-grid frame">
            <div className="hero-copy hero-entrance">
              <RuleLabel>Senior Technical Sales Engineer · Key Account Manager · Estimator</RuleLabel>
              <h1>A career engineered through <em>technical understanding, commercial judgement and stakeholder alignment.</em></h1>
              <p className="hero-summary">Over 15 years connecting engineering knowledge with commercial reality across civil infrastructure, mining, industrial gas, manufacturing and technical sales.</p>
              <p className="hero-detail">The throughline is practical: understand the requirement, test what will work, align the people involved, and stay accountable from enquiry through delivery.</p>
              <div className="hero-actions">
                <a className="button button-lime" href="#experience">Explore the career <ArrowDownRight size={16} /></a>
                <a className="button button-quiet" href="#decision">How decisions get made <MoveRight size={16} /></a>
              </div>
            </div>
            <div className="hero-visual hero-entrance">
              <figure className="hero-image-wrap">
                <img src={imageAssets.hero} alt="Representative industrial engineering environment" width={1600} height={1000} fetchPriority="high" decoding="async" />
                <figcaption>Representative work environment · contextual imagery, not a portrait</figcaption>
              </figure>
              <aside className="hero-aside">
                <span className="aside-index">01 / Operating principle</span>
                <strong>Technical depth that travels.</strong>
                <p>From CAD/CAM and precision fabrication to gas systems, geosynthetics, estimating and key-account leadership.</p>
              </aside>
            </div>
          </div>
          <div className="frame metric-strip" aria-label="Career highlights">
            <div><b>15+</b><span>years in technical-commercial roles</span></div>
            <div><b>$2M+</b><span>annual maintenance contracts generated</span></div>
            <div><b>98%</b><span>key-account retention at UniGAZ</span></div>
            <div><b>40%</b><span>service-agreement value growth</span></div>
            <div><b>22%</b><span>year-on-year revenue increase</span></div>
          </div>
        </section>

        <section className="section paper-section" id="journey">
          <div className="frame">
            <SectionTitle eyebrow="01 / Career trajectory" title={<>Technical depth, <em>carried forward.</em></>} copy="The career moves from specialist technical products into fabrication, estimating, field assessment, industrial gas, account leadership and technical sales across civil and environmental infrastructure." />
            <div className="journey-rail" aria-label="Career timeline">
              {roles.map((role) => <a href={`#role-${role.number}`} key={role.number}><span>{role.number}</span><b>{role.company}</b><small>{role.period}</small></a>)}
            </div>
          </div>
        </section>

        <section className="section decision-section" id="decision">
          <div className="frame">
            <SectionTitle eyebrow="02 / Decision pattern" title={<>From a technical question to a <em>credible next action.</em></>} copy="This is not a slogan. It describes the recurring operating pattern visible across the roles: technical information is translated into a commercially credible next action, with the right stakeholders aligned around it." />
            <div className="decision-note"><Ruler size={18} /><p>A drawing or specification is only the starting point. The work is determining what it means in application, what the commercial constraints allow, who must agree, and what needs to happen next.</p></div>
            <div className="decision-grid">
              {decisionSteps.map(([number, title, copy, image]) => <article className="decision-card" key={number}>
                <img src={image} alt="" width={960} height={540} loading="lazy" decoding="async" />
                <p>{number}</p><h3>{title}</h3><span>{copy}</span>
              </article>)}
            </div>
            <p className="image-note">Image integrity · representative process imagery provides context only. Career claims and performance metrics derive from the supplied résumé content.</p>
          </div>
        </section>

        <section className="section experience-section" id="experience">
          <div className="frame">
            <SectionTitle eyebrow="03 / Role chapters" title={<>The work behind the <em>title.</em></>} copy="Each chapter traces the operating environment, work performed, stakeholder network and capability carried into the next stage." />
            <div className="roles-list">
              {roles.map((role, index) => <article className={`role-card role-card-${index + 1}`} id={`role-${role.number}`} key={role.number}>
                <div className="role-media"><img src={role.image} alt="Representative industrial context" width={960} height={720} loading="lazy" decoding="async" /><span className="role-number">{role.number}</span><span className="role-caption">Representative industry context</span></div>
                <div className="role-content">
                  <div className="role-meta"><span><MapPin size={13} /> {role.location}</span><span>{role.period}</span></div>
                  <h3>{role.company}</h3><p className="role-title">{role.title}</p><p className="role-summary">{role.summary}</p>
                  <div className="role-columns">
                    <div><RuleLabel>Scope of work</RuleLabel><div className="chip-row">{role.scope.map((item) => <span key={item}>{item}</span>)}</div></div>
                    <div><RuleLabel>Stakeholders</RuleLabel><div className="chip-row muted-chips">{role.stakeholders.map((item) => <span key={item}>{item}</span>)}</div></div>
                  </div>
                  <details className="role-details"><summary>View detailed responsibilities <ChevronDown size={17} /></summary><div className="detail-content"><ul>{role.responsibilities.map((item) => <li key={item}>{item}</li>)}</ul><aside><RuleLabel>What this chapter added</RuleLabel><p>{role.added}</p></aside></div></details>
                </div>
              </article>)}
            </div>
          </div>
        </section>

        <section className="section impact-section" id="impact">
          <div className="frame">
            <div className="impact-grid">
              <div className="impact-intro"><RuleLabel>04 / Evidence of impact</RuleLabel><h2>Impact is built into the <em>operating model.</em></h2><p>Selected outcomes from technical-commercial roles where sales, delivery and stakeholder confidence are connected.</p></div>
              <div><b>$2M+</b><span>annual maintenance contracts generated</span></div><div><b>98%</b><span>key-account retention maintained</span></div><div><b>40%</b><span>service-agreement value growth</span></div><div><b>22%</b><span>year-on-year revenue increase</span></div><div><b>30%</b><span>faster proposal turnaround</span></div>
            </div>
          </div>
        </section>

        <section className="section paper-section" id="capabilities">
          <div className="frame capability-layout">
            <SectionTitle eyebrow="05 / Capability system" title={<>A practical range of <em>technical-commercial tools.</em></>} copy="A cross-functional profile shaped by field conversations, project requirements, cost logic, production constraints and customer outcomes." />
            <div className="capability-grid">
              <article><Target size={21} /><h3>Technical interpretation</h3><p>Drawings, specifications, BOQs, site conditions, compliance and application requirements.</p></article>
              <article><BriefcaseBusiness size={21} /><h3>Commercial development</h3><p>Quotations, tenders, pricing, margins, supplier negotiation and account growth.</p></article>
              <article><Network size={21} /><h3>Stakeholder alignment</h3><p>Customers, engineers, procurement, production, field teams and leadership.</p></article>
              <article><FileText size={21} /><h3>Delivery ownership</h3><p>Enquiry triage, proposals, handover, coordination, quality control and follow-through.</p></article>
            </div>
            <div className="tool-row"><RuleLabel>Working tools & environments</RuleLabel><div>{["AutoCAD", "CAD/CAM", "TruTops", "Salesforce", "RFQ / RFT", "BOQ & estimating", "Technical proposals", "Site assessment"].map((tool) => <span key={tool}>{tool}</span>)}</div></div>
          </div>
        </section>
      </main>

      <footer className="site-footer" id="contact">
        <div className="frame footer-layout">
          <div className="footer-brand"><span className="brand-mark"><img src={imageAssets.logo} alt="" /><i aria-hidden="true">AV</i></span><h2>Technical detail,<br /><em>carried through.</em></h2></div>
          <div><RuleLabel>Professional focus</RuleLabel><p>Technical sales engineering, key-account management, estimating, tendering and business development in complex industrial environments.</p></div>
          <div className="footer-contact"><RuleLabel>Direct contact</RuleLabel><p>Based in Melbourne, Victoria. Available for technical sales, key-account management, estimating and business-development conversations.</p><div className="contact-links"><a href="mailto:anwarvahid@hotmail.com"><Mail size={15} /><span>Email<br /><b>anwarvahid@hotmail.com</b></span></a><a href="tel:+61466771177"><Phone size={15} /><span>Mobile<br /><b>0466 771 177</b></span></a><span className="contact-location"><MapPin size={15} /> Melbourne, VIC</span></div><a className="footer-action" href="#top">Back to top <ArrowUpRight size={15} /></a></div>
        </div>
        <div className="frame footer-bottom"><span>© {new Date().getFullYear()} Anwar Vahid</span><span>Career engineered</span><span><CircleDot size={13} /> Contextual imagery only</span></div>
      </footer>
    </div>
  );
}
